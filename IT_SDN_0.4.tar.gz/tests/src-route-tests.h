#ifndef SRC_ROUTE_TESTS_H
#define SRC_ROUTE_TESTS_H

void test_send_src_rt_csf();

void test_send_src_rt_csf_incomplete();

void test_send_src_rt_dsf();

void test_send_src_rt_dsf_incomplete();

void test_send_mult_dsf();

void test_send_mult_csf();

#endif // SRC_ROUTE_TESTS_H
