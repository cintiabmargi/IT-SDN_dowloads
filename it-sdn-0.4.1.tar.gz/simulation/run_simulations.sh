#!/bin/bash
set -e
set -x
#set -v

tput reset

source path_simulation.sh

telegram_id="MY_IDENTIFICATION"

MIN_ITER=1
MAX_ITER=1
LIMIT_ITER=1 #max simulations running in parallel

# nodes_v=(16 25 36 49 64)
nodes_v=(16)

# topologies=(GRID-FULL GRID-RND GRID-CTA)
topologies=(GRID)

# nd_possibilities=(NV CL BL) # Naive Collect and Baseline
nd_possibilities=(CL)

# datarates=(0.2 2)
datarates=(1)

sinks=(1)
#Controller/Sink positions (C = center, L = left, R = right, U = up, D = down)
cont_sink_position=(NEW) #CC CLU RDLU EDGE NEW)

#etx_energy_legend=(ETX_0_ENERGY_100 ETX_25_ENERGY_75 ETX_50_ENERGY_50 ETX_75_ENERGY_25 ETX_100_ENERGY_0)
# etx=(0.0 0.25 0.5 0.75 1.0)
# energy=(1.0 0.75 0.5 0.25 0.0)

# etx_energy_legend=(ETX_0_ENERGY_100 ETX_50_ENERGY_50 ETX_100_ENERGY_0)
# etx=(0.0 0.5 1.0)
# energy=(1.0 0.5 0.0)

#etx_energy_legend=(ETX_0_ENERGY_100)
#etx=(0.0)
#energy=(1.0)

etx_energy_legend=(ETX_100_ENERGY_0)
etx=(1.0)
energy=(0.0)

#etx_energy_legend=(MAMDANI_CENTROID)
#etx=(0.5)
#energy=(0.5)

#etx_energy_legend=(MAMDANI_MOM)
#etx=(0.5)
#energy=(0.5)

## datadistrs=(CTE EXP)
### datadistrs=(CTE)
## schedules=(CTK3 CTK7 IND)
### schedules=(CTK3 CTK7)

source it-sdn-config.sh

pidJava=()
pidController=()

run_cooja() {

		cd "${contiki_dir}${4}${cooja_dir}/dist"
		java -mx5120m -jar cooja.jar -nogui="$1" > $2 2>&1 &
#		java -mx5120m -jar cooja.jar -quickstart="$1" > $2 2>&1 &

		pidJava=(${pidJava[@]} $!)

		while [ ! -f $2 ]; do
			sleep 1s # wait time so serial socket is available
			echo "Waiting log"
		done

		while [ `grep -c "Listening on port" $2` -ne 1 ]; do
			sleep 1s # wait time so serial socket is available
			echo "Waiting for serial socket to become available"
		done

		"$controller_build_dir"/controller-pc $nnodes --platform offscreen > $3 2>&1 &

		#local pidController=$!
		pidController=(${pidController[@]} $!)

#		wait $pidJava
#		kill $pidController

}

# echo "" > makelog.log

mkdir -p $simulation_output_dir

for ((index_route = 0; index_route < ${#etx_energy_legend[@]}; index_route++)); do
	for sink in "${sinks[@]}"; do
		for nnodes in "${nodes_v[@]}"; do
			for topo in "${topologies[@]}"; do
				for nd in "${nd_possibilities[@]}"; do
					for position in "${cont_sink_position[@]}"; do
						for datarate in "${datarates[@]}"; do
							for iter in `seq $MIN_ITER $MAX_ITER`; do

								port=$((60000+$iter));

								# s - schedule (CTK - contiki default, IND - individual slots for each node)
								# n - number of nodes
								# d - data traffic type
								# l - lambda (data rate = 1/packet interval)
								# i - iteration (experimetn number)

								cooja_file="$simulation_files_dir/ITSDN_n${nnodes}_s${sink}_${topo}.csc"
								config_simulation_file="$simulation_output_dir/config_${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_d${datarate}_i${iter}.txt"
								cooja_motes_out_file="$simulation_output_dir/cooja_${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_d${datarate}_i${iter}.txt"
								cooja_log_file="$simulation_output_dir/logcooja_${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_d${datarate}_i${iter}.txt"
								controller_out_file="$simulation_output_dir/controller_${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_d${datarate}_i${iter}.txt"
								controller_log_file="$simulation_output_dir/logcontroller_${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_d${datarate}_i${iter}.txt"

								echo Cooja simulation file: $cooja_file
								echo Cooja logfile name: $cooja_motes_out_file
								echo Controller logfile name: $controller_out_file

								# Change the COOJA simuation file to save simulation log with a different name
								sed -i "s,my_output =.*,my_output = new FileWriter(\"$cooja_motes_out_file\");," ${cooja_file}

								# SIM_TIME_MS=1200000
								# SIM_TIME_MS=1800000
								# SIM_TIME_MS=60000
								# sed -i.bak "s,TIMEOUT.*,TIMEOUT($SIM_TIME_MS);," ${cooja_file}

								# Clean current binaries
								(

									sed -i "s,#define SDN_SIMULATION_N_SINKS.*,#define SDN_SIMULATION_N_SINKS ${sink}," "${build_dir}/enabled-node.c"

									cd "${controller_dir}/controller-pc"

									sed -i "s,DEFINES += WEIGHT_ETX.*,DEFINES += WEIGHT_ETX=${etx[$index_route]}," controller-pc.pro

									sed -i "s,DEFINES += WEIGHT_ENERGY.*,DEFINES += WEIGHT_ENERGY=${energy[$index_route]}," controller-pc.pro

									sed -i "s,<number>60.*,<number>${port}</number>," mainwindow.ui

									cd "${simulation_files_dir}"

									sed -i "s,<port>60.*,<port>${port}</port>," ${cooja_file} #n${nnodes}_${topo}_${position}.csc

									cd "$build_dir"

									sed -i "s,DEFINES+=GRID_CC_N.*,DEFINES+=GRID_CC_N${nnodes}," Makefile_enabled_node

									# alterar project-conf.h
									SDN_CONF_CD=""
									SDN_CONF_ND=""
									if [ "$nd" == "NV" ]; then
										SDN_CONF_CD="naive_directed_cd"
										SDN_CONF_ND="naive_sdn_nd"
										sed -i "s,^//\s*#undef NETSTACK_CONF_NETWORK,#undef NETSTACK_CONF_NETWORK," project-conf.h
										sed -i "s,^//\s*#define NETSTACK_CONF_NETWORK sdn_network_driver,#define NETSTACK_CONF_NETWORK sdn_network_driver," project-conf.h
										sed -i "s,^CONTIKI_WITH_RIME = 1,CONTIKI_WITH_RIME = 0," Makefile_enabled_node
										sed -i "s,^CONTIKI_WITH_RIME = 1,CONTIKI_WITH_RIME = 0," Makefile_controller_node
										sed -i "s,^CONTIKI_SOURCEFILES += collect-nd.c,# CONTIKI_SOURCEFILES += collect-nd.c," Makefile_enabled_node
										sed -i "s,^CONTIKI_SOURCEFILES += collect-nd.c,# CONTIKI_SOURCEFILES += collect-nd.c," Makefile_controller_node
									elif [ "$nd" == "CL" ]; then
										SDN_CONF_CD="null_sdn_cd"
										SDN_CONF_ND="collect_sdn_nd"
										sed -i "s,^\s*#undef NETSTACK_CONF_NETWORK,// #undef NETSTACK_CONF_NETWORK," project-conf.h
										sed -i "s,^\s*#define NETSTACK_CONF_NETWORK sdn_network_driver,// #define NETSTACK_CONF_NETWORK sdn_network_driver," project-conf.h
										sed -i "s,^CONTIKI_WITH_RIME = 0,CONTIKI_WITH_RIME = 1," Makefile_enabled_node
										sed -i "s,^CONTIKI_WITH_RIME = 0,CONTIKI_WITH_RIME = 1," Makefile_controller_node
										sed -i "s,^#\s*CONTIKI_SOURCEFILES += collect-nd.c,CONTIKI_SOURCEFILES += collect-nd.c," Makefile_enabled_node
										sed -i "s,^#\s*CONTIKI_SOURCEFILES += collect-nd.c,CONTIKI_SOURCEFILES += collect-nd.c," Makefile_controller_node

									# elif [ "$nd" == "BL" ]; then
									# 	SDN_CONF_CD=""
									# 	SDN_CONF_ND=""
									else
										echo "there is no such ND algorithm"
										continue
									fi
									sed -i "s,^#define SDN_CONF_CD.*,#define SDN_CONF_CD $SDN_CONF_CD," project-conf.h
									sed -i "s,^#define SDN_CONF_ND.*,#define SDN_CONF_ND $SDN_CONF_ND," project-conf.h

									echo "$SDN_CONF_CD""$SDN_CONF_ND"

									(make TARGET=sky clean -f Makefile_enabled_node >> $controller_log_file 2>&1)
									(make TARGET=sky -f Makefile_enabled_node sink-node >> $controller_log_file 2>&1)

									(make TARGET=sky clean -f Makefile_enabled_node >> $controller_log_file 2>&1)
									(make TARGET=sky -f Makefile_enabled_node enabled-node >> $controller_log_file 2>&1)

									(make TARGET=sky clean -f Makefile_controller_node >> $controller_log_file 2>&1)
									(make TARGET=sky -f Makefile_controller_node >> $controller_log_file 2>&1)

									error=$(grep -Ei "error" $controller_log_file)

									if [[ -n $error ]]; then
										finish_date=$(date +"%d/%m/%Y %H:%M")
										telegram-send "${telegram_id} - Compilation Error!. (${finish_date})"
									fi

									# Recompile the node code
									# SCHEDULE=$schedulenum \
									# 	SCHEDULE_LEN=$schedule_len \
									# 	DISTR=$datadistrnum \
									# 	DATARATE=$datarate \
									# 	NNODES=$nnodes \
									# 	TEST_TSCH_SEED="$(od -vAn -N2 -tu4 < /dev/urandom | xargs)" \
									# 	make \
									# 	> makelog.log
								)

								#controller recompilation
								(
									cd $controller_build_dir
									conf_path=$(pwd)

									#necessário apagar os arquivos pré compilados para recompilar todos os DEFINES
									if [[ $conf_path == $controller_build_dir ]]; then
										rm *
									fi

									DEFINES=""
									if [ "$nd" == "NV" ]; then
										# DEFINES="DEFINES+=SDN_NEIGHBORINFO_NEIGHBORS_TO_SRC"
										sed -i "s,#\s*DEFINES += SDN_NEIGHBORINFO_NEIGHBORS_TO_SRC,DEFINES += SDN_NEIGHBORINFO_NEIGHBORS_TO_SRC," ../controller-pc/controller-pc.pro
										sed -i "s,DEFINES += SDN_NEIGHBORINFO_SRC_TO_NEIGHBORS,#DEFINES += SDN_NEIGHBORINFO_SRC_TO_NEIGHBORS," ../controller-pc/controller-pc.pro
									elif [ "$nd" == "CL" ]; then
										# DEFINES="DEFINES+=SDN_NEIGHBORINFO_SRC_TO_NEIGHBORS SDN_NEIGHBORINFO_NEIGHBORS_TO_SRC"
										sed -i "s,#\s*DEFINES += SDN_NEIGHBORINFO_NEIGHBORS_TO_SRC,DEFINES += SDN_NEIGHBORINFO_NEIGHBORS_TO_SRC," ../controller-pc/controller-pc.pro
										sed -i "s,#\s*DEFINES += SDN_NEIGHBORINFO_SRC_TO_NEIGHBORS,DEFINES += SDN_NEIGHBORINFO_SRC_TO_NEIGHBORS," ../controller-pc/controller-pc.pro
									# elif [ "$nd" == "BL" ]; then
									# 	SDN_CONF_CD=""
									# 	SDN_CONF_ND=""
									else
										echo "there is no such ND algorithm"
										continue
									fi
									# $QMAKE ../controller-pc/controller-pc.pro "$DEFINES"
									($QMAKE ../controller-pc/controller-pc.pro >> $controller_log_file 2>&1)
									(touch ../sdn-process-packets-controller.c >> $controller_log_file 2>&1)
									($MAKE >> $controller_log_file 2>&1)
								)

								log_config

								# if [ $? != 0 ]; then
								# 	echo error: Compilation problem! \($outfile\)
								# else
								# Run the COOJA simulation
								run_cooja `readlink -f ${cooja_file}` "$cooja_log_file" "$controller_out_file" $iter
								#echo
								# fi
			#					sed -i.bak "s,my_output =.*,my_output = new FileWriter(\"/dev/null\");," ${cooja_file}
								# python sdn_get_statistics_preproc.py  $cooja_motes_out_file &
								finish_date=$(date +"%d/%m/%Y %H:%M")

								telegram-send "${telegram_id} - Starting simulation ${iter} ${cooja_file}. (${finish_date})"

								if [ ${#pidJava[@]} -eq $LIMIT_ITER ]; then
							#		echo "Waiting simulations finish. ${pidJava[@]}"
									wait ${pidJava[@]}

									#echo "Finishing controllers. ${pidController[@]}"
									kill ${pidController[@]}
									#killall controller-pc

									pidJava=()
									pidController=()
								fi
							done

							cd "${simulation_output_dir}"							

							mkdir -p "${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_${position}_d${datarate}"

							mv *${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_d${datarate}*.txt ${etx_energy_legend[$index_route]}_n${nnodes}_s${sink}_top${topo}_nd${nd}_${position}_d${datarate}
						done
					done
				done
			done
		done
	done

	#echo "Waiting simulations finish. ${pidJava[@]}"
	wait ${pidJava[@]}

	#echo "Finishing controllers. ${pidController[@]}"
	if [ ${#pidController[@]} -gt 0 ]; then
		kill ${pidController[@]}
	fi
	#killall controller-pc
done

#sed -i "s,my_output =.*,my_output = new FileWriter(\"/dev/null\");," ${cooja_file}

finish_date=$(date +"%d/%m/%Y %H:%M")
#echo "tschsimlog_s"$schedule"_n"$nnodes"_d"$datatype"_l"$datarate"_i"$iter
telegram-send "${telegram_id} - Simulation has finished. (${finish_date})"
echo END
