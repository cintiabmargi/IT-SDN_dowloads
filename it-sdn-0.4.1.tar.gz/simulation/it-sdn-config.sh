#!/bin/bash

# source path_simulation.sh

config_read=""

# Clear log file if exists
> "${config_log}"

function get_config() {

	config_read=$(grep -E "${2}" "${project_dir}/${1}")

	echo "${1}: ${config_read}" >> "${config_simulation_file}"
}

function log_config() {

    get_config "applications/project-conf.h" "^#define NETSTACK_CONF_RDC"

    config_read=(${config_read})

    if [[ ${config_read[2]} == "contikimac_driver" ]]; then

    	get_config "applications/Makefile_controller_node" "NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE"

    	get_config "applications/Makefile_enabled_node"	"NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE"
    fi

    get_config "controller-server/controller-pc/controller-pc.pro" "SDN_ROUTE_SENSIBILITY"

    get_config "applications/enabled-node.c" "#define SENSING_AT_SECONDS"

    get_config "applications/enabled-node.c" "#define SDN_SIMULATION_N_SINKS"

    get_config "applications/sink-node.c" "uint16_t sink_addrs[]"

    get_config "applications/project-conf.h" "#define COLLECT_CONF_ANNOUNCEMENTS"

    get_config "contiki-sdn/energy-manager.c" "#define MAX_ENERGY_NODE"

    get_config "contiki-sdn/energy-manager.c" "#define ENERGY_MANAGER_SIMULATE_BATTERY"

    get_config "contiki-sdn/energy-manager.c" "#define REPORT_BATTERY_LEVEL_EVERY_PERCENT"

    get_config "contiki-sdn/energy-manager.c" "#define TIME_TO_ENERGY_ESTIMATE_IN_SECONDS"

    get_config "controller-server/digraph/dijkstra.c" "#define PATH_FINDER_ALGORITHM"

    get_config "controller-server/controller-pc/controller-pc.pro" "SDN_CONF_METRIC"

    get_config "controller-server/digraph/mamdani-fuzzy-model-metric.c" "^    weight = get"

    # cat ${config_log}
}