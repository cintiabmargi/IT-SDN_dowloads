#!/bin/bash

#set -x
set -o errtrace

function dec2hex(){

	HEX_DIGITS="0123456789ABCDEF"
	
	dec_value=$1
	hex_value=""

	until [ $dec_value == 0 ]; do

	    rem_value=$((dec_value % 16))
	    dec_value=$((dec_value / 16))

	    hex_digit=${HEX_DIGITS:$rem_value:1}

	    hex_value="${hex_digit}${hex_value}"

	done

	if [[ ${#hex_value} -eq 0 ]]; then
		hex_value="00"
	elif [[ ${#hex_value} -eq 1 ]]; then
		hex_value="0${hex_value}"
	fi

	echo -e "${hex_value}"
}

#hex=(00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10 11 12 13 14 15 16 17 18 19 1A 1B 1C 1D 1E 1F 20 21 22 23 24 25 26 27 28 29 2A 2B 2C 2D 2E 2F 30 31 32 33 34 35 36 37 38 39 3A 3B 3C 3D 3E 3F 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F 50 51 52 53 54 55 56 57 58 59 5A 5B 5C 5D 5E 5F)

#source "${0%/*}/anim.sh"
function Render(){
	a=0
}

function get_data_rate() {

  _nodes=($1)

  _data_TX=0
  _data_RX=0

  _num_nodes=${#_nodes[@]}

 #  _tmp_data_sent=$(grep -E ":Packet Sent .+ \[SDN_PACKET_DATA\]" $2)
	# _tmp_data_received=$(grep -E "Receiving message from \[ " $2)

 #  grep -E ":Packet Sent .+ \[SDN_PACKET_DATA\]" $2 > _tmp_data_sent
	grep -E "=(RX|TX|TXA)=" $2 > _tmp_rx_tx

  for(( k=0; k<_num_nodes; k++)); do

		# ((_data_sent+=$(grep -Ec ":${_nodes[$k]}:Packet Sent .+ \[SDN_PACKET_DATA\]" _tmp_data_sent) ))
		# ((_data_received+=$(grep -Ec "Receiving message from \[ ${hex[${_nodes[$k]}]}" _tmp_data_received) ))

		((_data_TX+=$(grep -Ec " ${hex[${_nodes[$k]}]} 00 \]=TX=.5=" _tmp_rx_tx) ))
		((_data_RX+=$(grep -Ec " ${hex[${_nodes[$k]}]} 00 \]=RX=.5=" _tmp_rx_tx) ))

  done

  # ((_energy = _energy / _num_nodes))
  _data_rate=$(((_data_RX * 100) /_data_TX))
  echo " <<< ${_data_rate}"
}

count_scene=0

for folder in */ ; do

 	file_process="${folder///}.txt"
 	>$file_process

	# count_scene=${folder#*ENERGY_}
	# count_scene=${count_scene%%_*}

	description[$count_scene]=$folder

 	_node=${folder#*_n}
 	# _node=${_node:0:2}
 	_node=${_node%%_*}

 	_sink=${folder#*_s}
 	_sink=${_sink:0:1}

  unset node_address_dec
  unset node_address_hex

  for ((k=1; k<=_node; k++)); do

    node_address_dec[$k]="$k"
    node_address_hex[$k]="$(dec2hex $((k%256))) $(dec2hex $((k/256)))"
  done

  unset energy_map_all

	for files in $(ls -1 $folder | grep '^cooja_.*.txt'); do

		echo "Simulation: ${files}"
		echo "Simulation: ${files}" >> $file_process

		file_number=${files#*_}

		file_number=${file_number%.*}

    seq_number=${file_number##*i}

		server_file="${folder}controller_${file_number}.txt"

		_energy_consumed=0
		_energy_total=0

		control_packet_received=0

		grep -E ":E:" "${folder}${files}" > _tmp_energy

		for ((k=1; k<=${#node_address_dec[@]}; k++)); do
			bat=(`grep -E ":${node_address_dec[$k]}:E:.+mJ" _tmp_energy | tail -n1`)

			if [ ! -z "$bat" ]; then

				bat=${bat[1]}

				energy_map[${node_address_dec[$k]}]=$bat

				# ((energy_map_total[k]+=bat))
        		energy_map_all[${node_address_dec[$k]}]="${energy_map_all[${node_address_dec[$k]}]} ${bat}"

				((_energy_consumed += bat))

				((_energy_total ++))
			else
				energy_map[${node_address_dec[$k]}]=0
			fi

			# echo "$k :${node_address_dec[$k]}: $bat c ${_energy_consumed}"
		done

		((energy_consumed_node[$seq_number] = _energy_consumed / _energy_total))
		((energy_consumed[$seq_number] = _energy_consumed))

        _sim_time=$(tail -2 "${folder}${files}")
        _sim_time=${_sim_time%%:*}
        sim_time[$seq_number]=$((_sim_time / 1000000)) # convert to seconds

#######################################################
    grep -E "=(RX|TX|TXA)=" "${folder}${files}" > _tmp_rx_tx
		
    # SDN_PACKET_CONTROL_FLOW_SETUP = 0,
		packet_RX_00[$seq_number]=$(grep -Ec "=RX=00=" _tmp_rx_tx)
		packet_TX_00[$seq_number]=$(grep -Ec "=TX=00=" _tmp_rx_tx)
		# packet_TXA_00[$seq_number]=$(grep -Ec "=TXA=00=" _tmp_rx_tx)
		packet_TXA_00[$seq_number]=$(grep -Ec "Retransmitting control flow setup with NOT SDN_SOURCE_ROUTED" $server_file)
		((packet_TX_00[$seq_number] = packet_TX_00[$seq_number] - packet_TXA_00[$seq_number]))
		# SDN_PACKET_DATA_FLOW_SETUP = 1,
		packet_RX_01[$seq_number]=$(grep -Ec "=RX=01=" _tmp_rx_tx)
		packet_TX_01[$seq_number]=$(grep -Ec "=TX=01=" _tmp_rx_tx)
		# packet_TXA_01[$seq_number]=$(grep -Ec "=TXA=01=" _tmp_rx_tx)
		packet_TXA_01[$seq_number]=$(grep -Ec "Retransmitting data flow setup with NOT SDN_SOURCE_ROUTED" $server_file)
		((packet_TX_01[$seq_number] = packet_TX_01[$seq_number] - packet_TXA_01[$seq_number]))
		# SDN_PACKET_CONTROL_FLOW_REQUEST = 2,
		packet_RX_02[$seq_number]=$(grep -Ec "=RX=02=" _tmp_rx_tx)
		packet_TX_02[$seq_number]=$(grep -Ec "=TX=02=" _tmp_rx_tx)
		packet_TXA_02[$seq_number]=$(grep -Ec "=TXA=02=" _tmp_rx_tx)
		# SDN_PACKET_DATA_FLOW_REQUEST = 3,
		packet_RX_03[$seq_number]=$(grep -Ec "=RX=03=" _tmp_rx_tx)
		packet_TX_03[$seq_number]=$(grep -Ec "=TX=03=" _tmp_rx_tx)
		packet_TXA_03[$seq_number]=$(grep -Ec "=TXA=03=" _tmp_rx_tx) #reenvio
		# SDN_PACKET_NEIGHBOR_REPORT = 4,
		packet_RX_04[$seq_number]=$(grep -Ec "=RX=04=" _tmp_rx_tx)
		packet_TX_04[$seq_number]=$(grep -Ec "=TX=04=" _tmp_rx_tx)
		packet_TXA_04[$seq_number]=$(grep -Ec "=TXA=04=" _tmp_rx_tx) #reenvio
		# SDN_PACKET_DATA = 5,
		packet_RX_05[$seq_number]=$(grep -Ec "=RX=05=" _tmp_rx_tx)
		packet_TX_05[$seq_number]=$(grep -Ec "=TX=05=" _tmp_rx_tx)
		packet_TXA_05[$seq_number]=$(grep -Ec "=TXA=05=" _tmp_rx_tx)
		# SDN_PACKET_SRC_ROUTED_CONTROL_FLOW_SETUP = 6 + 0xE0,
		packet_RX_06[$seq_number]=$(grep -Ec "=RX=E6=" _tmp_rx_tx)
		packet_TX_06[$seq_number]=$(grep -Ec "=TX=E6=" _tmp_rx_tx)
		# packet_TXA_06[$seq_number]=$(grep -Ec "=TXA=E6=" _tmp_rx_tx)
		packet_TXA_06[$seq_number]=$(grep -Ec "Retransmitting control flow setup with SDN_SOURCE_ROUTED" $server_file)
		((packet_TX_06[$seq_number] = packet_TX_06[$seq_number] - packet_TXA_06[$seq_number]))
		# SDN_PACKET_SRC_ROUTED_DATA_FLOW_SETUP = 7 + 0xE0,
		packet_RX_07[$seq_number]=$(grep -Ec "=RX=E7=" _tmp_rx_tx)
		packet_TX_07[$seq_number]=$(grep -Ec "=TX=E7=" _tmp_rx_tx)
		# packet_TXA_07[$seq_number]=$(grep -Ec "=TXA=E7=" _tmp_rx_tx)
		packet_TXA_07[$seq_number]=$(grep -Ec "Retransmitting data flow setup with SDN_SOURCE_ROUTED" $server_file)
		((packet_TX_07[$seq_number] = packet_TX_07[$seq_number] - packet_TXA_07[$seq_number]))
		# SDN_PACKET_MULTIPLE_CONTROL_FLOW_SETUP = 8 + 0xD0,
		packet_RX_08[$seq_number]=$(grep -Ec "=RX=D8=" _tmp_rx_tx)
		packet_TX_08[$seq_number]=$(grep -Ec "=TX=D8=" _tmp_rx_tx)
		packet_TXA_08[$seq_number]=$(grep -Ec "=TXA=D8=" _tmp_rx_tx)
		# SDN_PACKET_MULTIPLE_DATA_FLOW_SETUP = 9 + 0xD0,
		packet_RX_09[$seq_number]=$(grep -Ec "=RX=D9=" _tmp_rx_tx)
		packet_TX_09[$seq_number]=$(grep -Ec "=TX=D9=" _tmp_rx_tx)
		packet_TXA_09[$seq_number]=$(grep -Ec "=TXA=D9=" _tmp_rx_tx)
		# SDN_PACKET_ND = 10,
		packet_RX_10[$seq_number]=$(grep -Ec "=RX=0A=" _tmp_rx_tx)
		packet_TX_10[$seq_number]=$(grep -Ec "=TX=0A=" _tmp_rx_tx)
		packet_TXA_10[$seq_number]=$(grep -Ec "=TXA=0A=" _tmp_rx_tx)
		# SDN_PACKET_CD = 11,
		packet_RX_11[$seq_number]=$(grep -Ec "=RX=0B=" _tmp_rx_tx)
		packet_TX_11[$seq_number]=$(grep -Ec "=TX=0B=" _tmp_rx_tx)
		packet_TXA_11[$seq_number]=$(grep -Ec "=TXA=0B=" _tmp_rx_tx)
		# SDN_PACKET_ACK_BY_FLOW_ID = 12,
		packet_RX_12[$seq_number]=$(grep -Ec "=RX=0C=" _tmp_rx_tx)
		packet_TX_12[$seq_number]=$(grep -Ec "=TX=0C=" _tmp_rx_tx)
		packet_TXA_12[$seq_number]=$(grep -Ec "=TXA=0C=" _tmp_rx_tx)
		# SDN_PACKET_SRC_ROUTED_ACK = 13,
		packet_RX_13[$seq_number]=$(grep -Ec "=RX=0D=" _tmp_rx_tx)
		packet_TX_13[$seq_number]=$(grep -Ec "=TX=0D=" _tmp_rx_tx)
		packet_TXA_13[$seq_number]=$(grep -Ec "=TXA=0D=" _tmp_rx_tx)
		# SDN_PACKET_REGISTER_FLOWID = 14,
		packet_RX_14[$seq_number]=$(grep -Ec "=RX=0E=" _tmp_rx_tx)
		packet_TX_14[$seq_number]=$(grep -Ec "=TX=0E=" _tmp_rx_tx)
		packet_TXA_14[$seq_number]=$(grep -Ec "=TXA=0E=" _tmp_rx_tx)
		# SDN_PACKET_ENERGY_REPORT = 15,
		packet_RX_15[$seq_number]=$(grep -Ec "=RX=0F=" _tmp_rx_tx)
		packet_TX_15[$seq_number]=$(grep -Ec "=TX=0F=" _tmp_rx_tx)
		packet_TXA_15[$seq_number]=$(grep -Ec "=TXA=0F=" _tmp_rx_tx) #reenvio
		# SDN_PACKET_ACK_BY_FLOW_ADDRESS = 16
		packet_RX_16[$seq_number]=$(grep -Ec "=RX=10=" _tmp_rx_tx)
		packet_TX_16[$seq_number]=$(grep -Ec "=TX=10=" _tmp_rx_tx)
		packet_TXA_16[$seq_number]=$(grep -Ec "=TXA=10=" _tmp_rx_tx)
    # SDN_PACKET_MNGT_CONT_SRC_RTD = 17,
    packet_RX_17[$seq_number]=$(grep -Ec "=RX=11=" _tmp_rx_tx)
    packet_TX_17[$seq_number]=$(grep -Ec "=TX=11=" _tmp_rx_tx)
    packet_TXA_17[$seq_number]=$(grep -Ec "=TXA=11=" _tmp_rx_tx)
    #SDN_PACKET_MNGT_NODE_DATA = 18,
    packet_RX_18[$seq_number]=$(grep -Ec "=RX=12=" _tmp_rx_tx)
    packet_TX_18[$seq_number]=$(grep -Ec "=TX=12=" _tmp_rx_tx)
    packet_TXA_18[$seq_number]=$(grep -Ec "=TXA=12=" _tmp_rx_tx)


		cooja_error[$seq_number]=$(grep -Eci "error" "${folder}${files}")
		controller_error[$seq_number]=$(grep -Eci "error" "${server_file}")

		((packet_control_TX[$seq_number]=packet_TX_00[$seq_number]+packet_TX_01[$seq_number]+packet_TX_02[$seq_number]+packet_TX_03[$seq_number]+packet_TX_04[$seq_number]+packet_TX_06[$seq_number]+packet_TX_07[$seq_number]+packet_TX_08[$seq_number]+packet_TX_09[$seq_number]+packet_TX_10[$seq_number]+packet_TX_11[$seq_number]+packet_TX_12[$seq_number]+packet_TX_13[$seq_number]+packet_TX_14[$seq_number]+packet_TX_15[$seq_number]+packet_TX_16[$seq_number]))

	    ((packet_control_TXA[$seq_number]=packet_TXA_00[$seq_number]+packet_TXA_01[$seq_number]+packet_TXA_02[$seq_number]+packet_TXA_03[$seq_number]+packet_TXA_04[$seq_number]+packet_TXA_06[$seq_number]+packet_TXA_07[$seq_number]+packet_TXA_08[$seq_number]+packet_TXA_09[$seq_number]+packet_TXA_10[$seq_number]+packet_TXA_11[$seq_number]+packet_TXA_12[$seq_number]+packet_TXA_13[$seq_number]+packet_TXA_14[$seq_number]+packet_TXA_15[$seq_number]+packet_TXA_16[$seq_number]))

		PDR[$seq_number]=$(bc <<< "scale=4;${packet_RX_05[$seq_number]} / ${packet_TX_05[$seq_number]}")

        echo "TIME_TOTAL: ${sim_time[$seq_number]}" >> $file_process

        echo "SDN_PACKET_CONTROL_TOTAL: TX ${packet_control_TX[$seq_number]} TXA ${packet_control_TXA[$seq_number]}" >> $file_process

		echo "SDN_PACKET_CONTROL_FLOW_SETUP: TX ${packet_TX_00[$seq_number]} TXA ${packet_TXA_00[$seq_number]} RX ${packet_RX_00[$seq_number]}" >> $file_process

		echo "SDN_PACKET_DATA_FLOW_SETUP: TX ${packet_TX_01[$seq_number]} TXA ${packet_TXA_01[$seq_number]} RX ${packet_RX_01[$seq_number]}" >> $file_process

		echo "SDN_PACKET_CONTROL_FLOW_REQUEST: TX ${packet_TX_02[$seq_number]} TXA ${packet_TXA_02[$seq_number]} RX ${packet_RX_02[$seq_number]}" >> $file_process

		echo "SDN_PACKET_DATA_FLOW_REQUEST: TX ${packet_TX_03[$seq_number]} TXA ${packet_TXA_03[$seq_number]} RX ${packet_RX_03[$seq_number]}" >> $file_process

		echo "SDN_PACKET_NEIGHBOR_REPORT: TX ${packet_TX_04[$seq_number]} TXA ${packet_TXA_04[$seq_number]} RX ${packet_RX_04[$seq_number]}" >> $file_process

		echo "SDN_PACKET_DATA: TX ${packet_TX_05[$seq_number]} TXA ${packet_TXA_05[$seq_number]} RX ${packet_RX_05[$seq_number]}" >> $file_process

		echo "SDN_PACKET_SRC_ROUTED_CONTROL_FLOW_SETUP: TX ${packet_TX_06[$seq_number]} TXA ${packet_TXA_06[$seq_number]} RX ${packet_RX_06[$seq_number]}" >> $file_process

		echo "SDN_PACKET_SRC_ROUTED_DATA_FLOW_SETUP: TX ${packet_TX_07[$seq_number]} TXA ${packet_TXA_07[$seq_number]} RX ${packet_RX_07[$seq_number]}" >> $file_process

		echo "SDN_PACKET_MULTIPLE_CONTROL_FLOW_SETUP: TX ${packet_TX_08[$seq_number]} TXA ${packet_TXA_08[$seq_number]} RX ${packet_RX_08[$seq_number]}" >> $file_process

		echo "SDN_PACKET_MULTIPLE_DATA_FLOW_SETUP: TX ${packet_TX_09[$seq_number]} TXA ${packet_TXA_09[$seq_number]} RX ${packet_RX_09[$seq_number]}" >> $file_process

		echo "SDN_PACKET_ND: TX ${packet_TX_10[$seq_number]} TXA ${packet_TXA_10[$seq_number]} RX ${packet_RX_10[$seq_number]}" >> $file_process

		echo "SDN_PACKET_CD: TX ${packet_TX_11[$seq_number]} TXA ${packet_TXA_11[$seq_number]} RX ${packet_RX_11[$seq_number]}" >> $file_process

		echo "SDN_PACKET_ACK_BY_FLOW_ID: TX ${packet_TX_12[$seq_number]} TXA ${packet_TXA_12[$seq_number]} RX ${packet_RX_12[$seq_number]}" >> $file_process

		echo "SDN_PACKET_SRC_ROUTED_ACK: TX ${packet_TX_13[$seq_number]} TXA ${packet_TXA_13[$seq_number]} RX ${packet_RX_13[$seq_number]}" >> $file_process

		echo "SDN_PACKET_REGISTER_FLOWID: TX ${packet_TX_14[$seq_number]} TXA ${packet_TXA_14[$seq_number]} RX ${packet_RX_14[$seq_number]}" >> $file_process

		echo "SDN_PACKET_ENERGY_REPORT: TX ${packet_TX_15[$seq_number]} TXA ${packet_TXA_15[$seq_number]} RX ${packet_RX_15[$seq_number]}" >> $file_process

    echo "SDN_PACKET_ACK_BY_FLOW_ADDRESS: TX ${packet_TX_16[$seq_number]} TXA ${packet_TXA_16[$seq_number]} RX ${packet_RX_16[$seq_number]}" >> $file_process

    echo "SDN_PACKET_MNGT_CONT_SRC_RTD: TX ${packet_TX_17[$seq_number]} TXA ${packet_TXA_17[$seq_number]} RX ${packet_RX_17[$seq_number]}" >> $file_process

    echo "SDN_PACKET_MNGT_NODE_DATA: TX ${packet_TX_18[$seq_number]} TXA ${packet_TXA_18[$seq_number]} RX ${packet_RX_18[$seq_number]}" >> $file_process

		# echo "Data_Rate_Hop: ${data_rate_hop}" >> $file_process

    oldIFS=$IFS
    IFS=","

    echo "Node_map_index: ${!nodes[*]}" >> $file_process

    echo "Node_map: ${nodes[*]}" >> $file_process

		echo "Energy_map_1D: ${energy_map[@]}" >> $file_process

		echo "Energy_map_2D:" >> $file_process
		
    #only for squared grid
    _root=$(echo "sqrt($_node)" | bc)

    for ((k=1; k<=_root; k++)); do
      
      echo -n "[" >> $file_process
		  
      for ((l=0; l<_root - 1; l++)); do
        echo -n "${energy_map[${node_address_dec[$k]}+((l*_root))]}," >> $file_process
      done

      echo -n "${energy_map[${node_address_dec[$k]}+((l*_root))]}" >> $file_process

      echo "]" >> $file_process
		done

    IFS=$oldIFS

		echo "Energy Consumed: ${energy_consumed[$seq_number]}" >> $file_process

		data_route_changed[$seq_number]=$(grep -Ec "Flow ID route was updated" $server_file)
		echo "Data route changes: ${data_route_changed[$seq_number]}" >> $file_process

		control_route_changed[$seq_number]=$(grep -Ec "Flow Address route was updated" $server_file)
		echo "Control route changes: ${control_route_changed[$seq_number]}" >> $file_process

		echo "Cooja line errors: ${cooja_error[$seq_number]}" >> $file_process
		echo "Cooja line errors: ${cooja_error[$seq_number]}"

		echo "Controller line errors: ${controller_error[$seq_number]}" >> $file_process
		echo "Controller line errors: ${controller_error[$seq_number]}"

		echo "" >> $file_process
	done;

###############################################################################################

  for ((k=1; k<=${#node_address_dec[@]}; k++)); do

    energy_map_total[${node_address_dec[$k]}]=$(echo ${energy_map_all[${node_address_dec[$k]}]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
    energy_map_stdev[${node_address_dec[$k]}]=$(echo ${energy_map_all[${node_address_dec[$k]}]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  done

  oldIFS=$IFS
  IFS=","

  energy_map_index_scene[$count_scene]="[${!energy_map_total[*]}]"
  energy_map_total_scene[$count_scene]="[${energy_map_total[*]}]"
  energy_map_stdev_scene[$count_scene]="[${energy_map_stdev[*]}]"


  # Finds the highest energy value from array
  maior=0

  for ((k=1; k<=${#node_address_dec[@]}; k++)); do
  	# if [[ ${energy_map_total[$k]} -gt $maior ]]; then 
	  maior=$(echo "${maior} ${energy_map_total[${node_address_dec[$k]}]}" | awk '{if ($1>$2){print $1}else{print $2}}')
  	# fi
  done

  for ((k=1; k<=${#node_address_dec[@]}; k++)); do
  	# if [[ ${energy_map_total[$k]} -gt $maior ]]; then 
	  energy_map_total_copy[${node_address_dec[$k]}]=$(echo "${maior} ${energy_map_total[${node_address_dec[$k]}]}" | awk '{print ($2/$1)}')
  	# fi
  done

   #only for squared grid
  for ((k=1; k<=_root; k++)); do
    
    _tmp="["
    _tmp2="["
    
    for ((l=0; l<_root - 1; l++)); do
      _tmp="${_tmp}${energy_map_total[${node_address_dec[$k]}+((l*_root))]}, "
      _tmp2="${_tmp2}${energy_map_total_copy[${node_address_dec[$k]}+((l*_root))]}, "
      # echo -n "${energy_map[${node_address_dec[$k]}+((l*_root))]}," >> $file_process
    done

    _tmp="${_tmp}${energy_map_total[${node_address_dec[$k]}+((l*_root))]}"
    _tmp2="${_tmp2}${energy_map_total_copy[${node_address_dec[$k]}+((l*_root))]}"

    energy_map_vector_scene[$count_scene]="${energy_map_vector_scene[$count_scene]} ${_tmp}],\n"
    energy_map_vector_scene_copy[$count_scene]="${energy_map_vector_scene_copy[$count_scene]} ${_tmp2}],\n"
  done

  IFS=$oldIFS

  sim_time_total[$count_scene]=$(echo ${sim_time[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')

  packet_RX_00_total[$count_scene]=$(echo ${packet_RX_00[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_01_total[$count_scene]=$(echo ${packet_RX_01[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_02_total[$count_scene]=$(echo ${packet_RX_02[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_03_total[$count_scene]=$(echo ${packet_RX_03[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_04_total[$count_scene]=$(echo ${packet_RX_04[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_05_total[$count_scene]=$(echo ${packet_RX_05[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_06_total[$count_scene]=$(echo ${packet_RX_06[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_07_total[$count_scene]=$(echo ${packet_RX_07[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_08_total[$count_scene]=$(echo ${packet_RX_08[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_09_total[$count_scene]=$(echo ${packet_RX_09[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_10_total[$count_scene]=$(echo ${packet_RX_10[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_11_total[$count_scene]=$(echo ${packet_RX_11[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_12_total[$count_scene]=$(echo ${packet_RX_12[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_13_total[$count_scene]=$(echo ${packet_RX_13[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_14_total[$count_scene]=$(echo ${packet_RX_14[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_15_total[$count_scene]=$(echo ${packet_RX_15[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_16_total[$count_scene]=$(echo ${packet_RX_16[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_17_total[$count_scene]=$(echo ${packet_RX_17[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_RX_18_total[$count_scene]=$(echo ${packet_RX_18[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')

  sim_time_stddev[$count_scene]=$(echo ${sim_time[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  packet_RX_00_stddev[$count_scene]=$(echo ${packet_RX_00[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_01_stddev[$count_scene]=$(echo ${packet_RX_01[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_02_stddev[$count_scene]=$(echo ${packet_RX_02[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_03_stddev[$count_scene]=$(echo ${packet_RX_03[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_04_stddev[$count_scene]=$(echo ${packet_RX_04[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_05_stddev[$count_scene]=$(echo ${packet_RX_05[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_06_stddev[$count_scene]=$(echo ${packet_RX_06[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_07_stddev[$count_scene]=$(echo ${packet_RX_07[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_08_stddev[$count_scene]=$(echo ${packet_RX_08[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_09_stddev[$count_scene]=$(echo ${packet_RX_09[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_10_stddev[$count_scene]=$(echo ${packet_RX_10[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_11_stddev[$count_scene]=$(echo ${packet_RX_11[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_12_stddev[$count_scene]=$(echo ${packet_RX_12[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_13_stddev[$count_scene]=$(echo ${packet_RX_13[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_14_stddev[$count_scene]=$(echo ${packet_RX_14[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_15_stddev[$count_scene]=$(echo ${packet_RX_15[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_16_stddev[$count_scene]=$(echo ${packet_RX_16[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_17_stddev[$count_scene]=$(echo ${packet_RX_17[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_RX_18_stddev[$count_scene]=$(echo ${packet_RX_18[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  packet_TX_00_total[$count_scene]=$(echo ${packet_TX_00[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_00_total[$count_scene]=$(echo ${packet_TXA_00[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_01_total[$count_scene]=$(echo ${packet_TX_01[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_01_total[$count_scene]=$(echo ${packet_TXA_01[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_02_total[$count_scene]=$(echo ${packet_TX_02[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_02_total[$count_scene]=$(echo ${packet_TXA_02[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_03_total[$count_scene]=$(echo ${packet_TX_03[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_03_total[$count_scene]=$(echo ${packet_TXA_03[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_04_total[$count_scene]=$(echo ${packet_TX_04[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_04_total[$count_scene]=$(echo ${packet_TXA_04[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_05_total[$count_scene]=$(echo ${packet_TX_05[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_05_total[$count_scene]=$(echo ${packet_TXA_05[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_06_total[$count_scene]=$(echo ${packet_TX_06[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_06_total[$count_scene]=$(echo ${packet_TXA_06[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_07_total[$count_scene]=$(echo ${packet_TX_07[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_07_total[$count_scene]=$(echo ${packet_TXA_07[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_08_total[$count_scene]=$(echo ${packet_TX_08[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_08_total[$count_scene]=$(echo ${packet_TXA_08[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_09_total[$count_scene]=$(echo ${packet_TX_09[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_09_total[$count_scene]=$(echo ${packet_TXA_09[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_10_total[$count_scene]=$(echo ${packet_TX_10[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_10_total[$count_scene]=$(echo ${packet_TXA_10[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_11_total[$count_scene]=$(echo ${packet_TX_11[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_11_total[$count_scene]=$(echo ${packet_TXA_11[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_12_total[$count_scene]=$(echo ${packet_TX_12[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_12_total[$count_scene]=$(echo ${packet_TXA_12[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_13_total[$count_scene]=$(echo ${packet_TX_13[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_13_total[$count_scene]=$(echo ${packet_TXA_13[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_14_total[$count_scene]=$(echo ${packet_TX_14[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_14_total[$count_scene]=$(echo ${packet_TXA_14[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_15_total[$count_scene]=$(echo ${packet_TX_15[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_15_total[$count_scene]=$(echo ${packet_TXA_15[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_16_total[$count_scene]=$(echo ${packet_TX_16[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_16_total[$count_scene]=$(echo ${packet_TXA_16[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_17_total[$count_scene]=$(echo ${packet_TX_17[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_17_total[$count_scene]=$(echo ${packet_TXA_17[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TX_18_total[$count_scene]=$(echo ${packet_TX_18[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_TXA_18_total[$count_scene]=$(echo ${packet_TXA_18[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')

  packet_TX_00_stddev[$count_scene]=$(echo ${packet_TX_00[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_00_stddev[$count_scene]=$(echo ${packet_TXA_00[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_01_stddev[$count_scene]=$(echo ${packet_TX_01[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_01_stddev[$count_scene]=$(echo ${packet_TXA_01[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_02_stddev[$count_scene]=$(echo ${packet_TX_02[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_02_stddev[$count_scene]=$(echo ${packet_TXA_02[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_03_stddev[$count_scene]=$(echo ${packet_TX_03[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_03_stddev[$count_scene]=$(echo ${packet_TXA_03[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_04_stddev[$count_scene]=$(echo ${packet_TX_04[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_04_stddev[$count_scene]=$(echo ${packet_TXA_04[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_05_stddev[$count_scene]=$(echo ${packet_TX_05[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_05_stddev[$count_scene]=$(echo ${packet_TXA_05[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_06_stddev[$count_scene]=$(echo ${packet_TX_06[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_06_stddev[$count_scene]=$(echo ${packet_TXA_06[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_07_stddev[$count_scene]=$(echo ${packet_TX_07[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_07_stddev[$count_scene]=$(echo ${packet_TXA_07[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_08_stddev[$count_scene]=$(echo ${packet_TX_08[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_08_stddev[$count_scene]=$(echo ${packet_TXA_08[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_09_stddev[$count_scene]=$(echo ${packet_TX_09[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_09_stddev[$count_scene]=$(echo ${packet_TXA_09[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_10_stddev[$count_scene]=$(echo ${packet_TX_10[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_10_stddev[$count_scene]=$(echo ${packet_TXA_10[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_11_stddev[$count_scene]=$(echo ${packet_TX_11[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_11_stddev[$count_scene]=$(echo ${packet_TXA_11[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_12_stddev[$count_scene]=$(echo ${packet_TX_12[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_12_stddev[$count_scene]=$(echo ${packet_TXA_12[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_13_stddev[$count_scene]=$(echo ${packet_TX_13[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_13_stddev[$count_scene]=$(echo ${packet_TXA_13[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_14_stddev[$count_scene]=$(echo ${packet_TX_14[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_14_stddev[$count_scene]=$(echo ${packet_TXA_14[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_15_stddev[$count_scene]=$(echo ${packet_TX_15[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_15_stddev[$count_scene]=$(echo ${packet_TXA_15[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_16_stddev[$count_scene]=$(echo ${packet_TX_16[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_16_stddev[$count_scene]=$(echo ${packet_TXA_16[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_17_stddev[$count_scene]=$(echo ${packet_TX_17[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_17_stddev[$count_scene]=$(echo ${packet_TXA_17[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TX_18_stddev[$count_scene]=$(echo ${packet_TX_18[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')
  packet_TXA_18_stddev[$count_scene]=$(echo ${packet_TXA_18[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  data_route_changed_total[count_scene]=$(echo ${data_route_changed[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  data_route_changed_stddev[$count_scene]=$(echo ${data_route_changed[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  control_route_changed_total[count_scene]=$(echo ${control_route_changed[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  control_route_changed_stddev[$count_scene]=$(echo ${control_route_changed[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  packet_control_TX_total[$count_scene]=$(echo ${packet_control_TX[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_control_TX_total_stddev[$count_scene]=$(echo ${packet_control_TX[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  packet_control_TXA_total[$count_scene]=$(echo ${packet_control_TXA[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  packet_control_TXA_total_stddev[$count_scene]=$(echo ${packet_control_TXA[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  energy_total[$count_scene]=$(echo ${energy_consumed[*]} | awk 'NF {sum=0;for (i=1;i<=NF;i++){sum+=$i}; print (sum/NF)}')
  energy_stddev[$count_scene]=$(echo ${energy_consumed[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  PDR_total[$count_scene]=$(echo ${PDR[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')
  PDR_stddev[$count_scene]=$(echo ${PDR[@]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

  ((count_scene++))

done

IFS=","

echo "" > results.txt

echo "DESCRIPTION = [${description[*]}]" >> results.txt

echo "TIME_TOTAL = [${sim_time_total[*]}]" >> results.txt
echo "TIME_stdev = [${sim_time_stddev[*]}]" >> results.txt

echo "PDR_total = [${PDR_total[*]}]" >> results.txt
echo "PDR_stdev = [${PDR_stddev[*]}]" >> results.txt

echo "ENERGY_TOTAL = [${energy_total[*]}]" >> results.txt
echo "ENERGY_TOTAL_stddev = [${energy_stddev[*]}]" >> results.txt

echo "PACKET_CONTROL_TX = [${packet_control_TX_total[*]}]" >> results.txt
echo "PACKET_CONTROL_TX_stddev = [${packet_control_TX_total_stddev[*]}]" >> results.txt

echo "PACKET_CONTROL_TXA = [${packet_control_TXA_total[*]}]" >> results.txt
echo "PACKET_CONTROL_TXA_stdev = [${packet_control_TXA_total_stddev[*]}]" >> results.txt

echo "SDN_PACKET_CONTROL_FLOW_SETUP_TX = [${packet_TX_00_total[*]}]" >> results.txt
echo "SDN_PACKET_CONTROL_FLOW_SETUP_TX_stddev = [${packet_TX_00_stddev[*]}]" >> results.txt

echo "SDN_PACKET_CONTROL_FLOW_SETUP_RX = [${packet_RX_00_total[*]}]" >> results.txt
echo "SDN_PACKET_CONTROL_FLOW_SETUP_RX_stddev = [${packet_RX_00_stddev[*]}]" >> results.txt

echo "SDN_PACKET_DATA_FLOW_SETUP_TX = [${packet_TX_01_total[*]}]" >> results.txt
echo "SDN_PACKET_DATA_FLOW_SETUP_TX_stddev = [${packet_TX_01_stddev[*]}]" >> results.txt

echo "SDN_PACKET_DATA_FLOW_SETUP_RX = [${packet_RX_01_total[*]}]" >> results.txt
echo "SDN_PACKET_DATA_FLOW_SETUP_RX_stddev = [${packet_RX_01_stddev[*]}]" >> results.txt

echo "SDN_PACKET_CONTROL_FLOW_REQUEST_TX = [${packet_TX_02_total[*]}]" >> results.txt
echo "SDN_PACKET_CONTROL_FLOW_REQUEST_TX_stddev = [${packet_TX_02_stddev[*]}]" >> results.txt

echo "SDN_PACKET_CONTROL_FLOW_REQUEST_RX = [${packet_RX_02_total[*]}]" >> results.txt
echo "SDN_PACKET_CONTROL_FLOW_REQUEST_RX_stddev = [${packet_RX_02_stddev[*]}]" >> results.txt

echo "SDN_PACKET_DATA_FLOW_REQUEST_TX = [${packet_TX_03_total[*]}]" >> results.txt
echo "SDN_PACKET_DATA_FLOW_REQUEST_TX_stddev = [${packet_TX_03_stddev[*]}]" >> results.txt

echo "SDN_PACKET_DATA_FLOW_REQUEST_RX = [${packet_RX_03_total[*]}]" >> results.txt
echo "SDN_PACKET_DATA_FLOW_REQUEST_RX_stddev = [${packet_RX_03_stddev[*]}]" >> results.txt

echo "SDN_PACKET_NEIGHBOR_REPORT_TX = [${packet_TX_04_total[*]}]" >> results.txt
echo "SDN_PACKET_NEIGHBOR_REPORT_TX_stddev = [${packet_TX_04_stddev[*]}]" >> results.txt

echo "SDN_PACKET_NEIGHBOR_REPORT_RX = [${packet_RX_04_total[*]}]" >> results.txt
echo "SDN_PACKET_NEIGHBOR_REPORT_RX_stddev = [${packet_RX_04_stddev[*]}]" >> results.txt

echo "SDN_PACKET_DATA_TX = [${packet_TX_05_total[*]}]" >> results.txt
echo "SDN_PACKET_DATA_TX_stddev = [${packet_TX_05_stddev[*]}]" >> results.txt

echo "SDN_PACKET_DATA_RX = [${packet_RX_05_total[*]}]" >> results.txt
echo "SDN_PACKET_DATA_RX_stddev = [${packet_RX_05_stddev[*]}]" >> results.txt

echo "SDN_PACKET_SRC_ROUTED_CONTROL_FLOW_SETUP_TX = [${packet_TX_06_total[*]}]" >> results.txt
echo "SDN_PACKET_SRC_ROUTED_CONTROL_FLOW_SETUP_TX_stddev = [${packet_TX_06_stddev[*]}]" >> results.txt

echo "SDN_PACKET_SRC_ROUTED_CONTROL_FLOW_SETUP_RX = [${packet_RX_06_total[*]}]" >> results.txt
echo "SDN_PACKET_SRC_ROUTED_CONTROL_FLOW_SETUP_RX_stddev = [${packet_RX_06_stddev[*]}]" >> results.txt

echo "SDN_PACKET_SRC_ROUTED_DATA_FLOW_SETUP_TX = [${packet_TX_07_total[*]}]" >> results.txt
echo "SDN_PACKET_SRC_ROUTED_DATA_FLOW_SETUP_TX_stddev = [${packet_TX_07_stddev[*]}]" >> results.txt

echo "SDN_PACKET_SRC_ROUTED_DATA_FLOW_SETUP_RX = [${packet_RX_07_total[*]}]" >> results.txt
echo "SDN_PACKET_SRC_ROUTED_DATA_FLOW_SETUP_RX_stddev = [${packet_RX_07_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MULTIPLE_CONTROL_FLOW_SETUP_TX = [${packet_TX_08_total[*]}]" >> results.txt
echo "SDN_PACKET_MULTIPLE_CONTROL_FLOW_SETUP_TX_stddev = [${packet_TX_08_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MULTIPLE_CONTROL_FLOW_SETUP_RX = [${packet_RX_08_total[*]}]" >> results.txt
echo "SDN_PACKET_MULTIPLE_CONTROL_FLOW_SETUP_RX_stddev = [${packet_RX_08_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MULTIPLE_DATA_FLOW_SETUP_TX = [${packet_TX_09_total[*]}]" >> results.txt
echo "SDN_PACKET_MULTIPLE_DATA_FLOW_SETUP_TX_stddev = [${packet_TX_09_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MULTIPLE_DATA_FLOW_SETUP_RX = [${packet_RX_09_total[*]}]" >> results.txt
echo "SDN_PACKET_MULTIPLE_DATA_FLOW_SETUP_RX_stddev = [${packet_RX_09_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ND_TX = [${packet_TX_10_total[*]}]" >> results.txt
echo "SDN_PACKET_ND_TX_stddev = [${packet_TX_10_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ND_RX = [${packet_RX_10_total[*]}]" >> results.txt
echo "SDN_PACKET_ND_RX_stddev = [${packet_RX_10_stddev[*]}]" >> results.txt

echo "SDN_PACKET_CD_TX = [${packet_TX_11_total[*]}]" >> results.txt
echo "SDN_PACKET_CD_TX_stddev = [${packet_TX_11_stddev[*]}]" >> results.txt

echo "SDN_PACKET_CD_RX = [${packet_RX_11_total[*]}]" >> results.txt
echo "SDN_PACKET_CD_RX_stddev = [${packet_RX_11_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ACK_BY_FLOW_ID_TX = [${packet_TX_12_total[*]}]" >> results.txt
echo "SDN_PACKET_ACK_BY_FLOW_ID_TX_stddev = [${packet_TX_12_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ACK_BY_FLOW_ID_RX = [${packet_RX_12_total[*]}]" >> results.txt
echo "SDN_PACKET_ACK_BY_FLOW_ID_RX_stddev = [${packet_RX_12_stddev[*]}]" >> results.txt

echo "SDN_PACKET_SRC_ROUTED_ACK_TX = [${packet_TX_13_total[*]}]" >> results.txt
echo "SDN_PACKET_SRC_ROUTED_ACK_TX_stddev = [${packet_TX_13_stddev[*]}]" >> results.txt

echo "SDN_PACKET_SRC_ROUTED_ACK_RX = [${packet_RX_13_total[*]}]" >> results.txt
echo "SDN_PACKET_SRC_ROUTED_ACK_RX_stddev = [${packet_RX_13_stddev[*]}]" >> results.txt

echo "SDN_PACKET_REGISTER_FLOWID_TX = [${packet_TX_14_total[*]}]" >> results.txt
echo "SDN_PACKET_REGISTER_FLOWID_TX_stddev = [${packet_TX_14_stddev[*]}]" >> results.txt

echo "SDN_PACKET_REGISTER_FLOWID_RX = [${packet_RX_14_total[*]}]" >> results.txt
echo "SDN_PACKET_REGISTER_FLOWID_RX_stddev = [${packet_RX_14_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ENERGY_REPORT_TX = [${packet_TX_15_total[*]}]" >> results.txt
echo "SDN_PACKET_ENERGY_REPORT_TX_stddev = [${packet_TX_15_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ENERGY_REPORT_RX = [${packet_RX_15_total[*]}]" >> results.txt
echo "SDN_PACKET_ENERGY_REPORT_RX_stddev = [${packet_RX_15_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ACK_BY_FLOW_ADDRESS_TX = [${packet_TX_16_total[*]}]" >> results.txt
echo "SDN_PACKET_ACK_BY_FLOW_ADDRESS_TX_stddev = [${packet_TX_16_stddev[*]}]" >> results.txt

echo "SDN_PACKET_ACK_BY_FLOW_ADDRESS_RX = [${packet_RX_16_total[*]}]" >> results.txt
echo "SDN_PACKET_ACK_BY_FLOW_ADDRESS_RX_stddev = [${packet_RX_16_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MNGT_CONT_SRC_RTD_TX = [${packet_TX_17_total[*]}]" >> results.txt
echo "SDN_PACKET_MNGT_CONT_SRC_RTD_TX_stddev = [${packet_TX_17_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MNGT_CONT_SRC_RTD_RX = [${packet_RX_17_total[*]}]" >> results.txt
echo "SDN_PACKET_MNGT_CONT_SRC_RTD_RX_stddev = [${packet_RX_17_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MNGT_NODE_DATA_TX = [${packet_TX_18_total[*]}]" >> results.txt
echo "SDN_PACKET_MNGT_NODE_DATA_TX_stddev = [${packet_TX_18_stddev[*]}]" >> results.txt

echo "SDN_PACKET_MNGT_NODE_DATA_RX = [${packet_RX_18_total[*]}]" >> results.txt
echo "SDN_PACKET_MNGT_NODE_DATA_RX_stddev = [${packet_RX_18_stddev[*]}]" >> results.txt

echo "DATA_ROUTE_CHANGED = [${data_route_changed_total[*]}]" >> results.txt
echo "DATA_ROUTE_CHANGED_stdev = [${data_route_changed_stddev[*]}]" >> results.txt

echo "CONTROL_ROUTE_CHANGED = [${control_route_changed_total[*]}]" >> results.txt
echo "CONTROL_ROUTE_CHANGED_stdev = [${control_route_changed_stddev[*]}]" >> results.txt

for ((k=0; k<${#node_address_dec[@]}; k++)); do

  energy_map_total[$k]=$(echo ${energy_map_all[$k]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (sum/NF)}')

  energy_map_stdev[$k]=$(echo ${energy_map_all[$k]} | awk 'NF {sum=0;ssq=0;for (i=1;i<=NF;i++){sum+=$i;ssq+=$i^2}; print (ssq/NF-(sum/NF)^2)^0.5}')

done

for k in ${!energy_map_index_scene[@]}; do

  echo "Scene ${description[$k]}" >> results.txt 
  echo "energy_map_1D_index = ${energy_map_index_scene[$k]}" >> results.txt  
  echo "energy_map_1D = ${energy_map_total_scene[$k]}" >> results.txt  
  echo "energy_map_1D_stdev = ${energy_map_stdev_scene[$k]}" >> results.txt  
  echo -e "Energy_map_2D: ${energy_map_vector_scene[$k]}" >> results.txt 
  echo -e "Energy_map_2D_diff: ${energy_map_vector_scene_copy[$k]}" >> results.txt 
  echo ""
done


# rm tmp
# rm tmp2
rm _tmp*

echo -e "\nThat's all Folks!\n"
