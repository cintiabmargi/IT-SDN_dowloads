#!/bin/bash
SDN_CONF_CD="naive_directed_cd" SDN_CONF_ND="improved_naive_sdn_nd" ./change_to_unidir.sh
